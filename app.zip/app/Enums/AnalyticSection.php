<?php

namespace App\Enums;

interface AnalyticSection
{
    const HEAD   = 5;
    const BODY   = 10;
    const FOOTER = 15;
}
