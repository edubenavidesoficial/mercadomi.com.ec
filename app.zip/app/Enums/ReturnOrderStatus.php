<?php

namespace App\Enums;

interface ReturnOrderStatus
{
    const PENDING = 5;
    const ACCEPT = 10;
    const REJECTED = 15;
}
