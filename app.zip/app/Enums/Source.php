<?php

namespace App\Enums;

interface Source
{

    const WEB = 5;
    const APP = 10;
    const POS = 15;

}
