<?php

namespace App\Enums;

interface ShippingType
{
    const FREE   = 5;
    const FLAT_RATE = 10;
}
