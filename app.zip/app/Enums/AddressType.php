<?php

namespace App\Enums;

interface AddressType
{
    const SHIPPING = 5;
    const BILLING  = 10;
}
