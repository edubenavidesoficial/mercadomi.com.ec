<?php

namespace App\Enums;

interface PromotionType
{
    const SMALL = 5;
    const BIG = 10;
}
