<?php

namespace App\Enums;

interface DisplayMode
{
    const LTR   = 5;
    const RTL = 10;
}
