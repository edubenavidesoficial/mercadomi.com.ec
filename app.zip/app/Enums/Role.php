<?php

namespace App\Enums;

interface Role
{
    const ADMIN        = 1;
    const CUSTOMER     = 2;
    const MANAGER      = 3;
    const POS_OPERATOR = 4;
    const STUFF        = 5;
}
