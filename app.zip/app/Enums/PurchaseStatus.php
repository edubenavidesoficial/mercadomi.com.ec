<?php

namespace App\Enums;

interface PurchaseStatus
{
    const PENDING = 5;
    const ORDERED = 10;
    const RECEIVED = 15;
}
